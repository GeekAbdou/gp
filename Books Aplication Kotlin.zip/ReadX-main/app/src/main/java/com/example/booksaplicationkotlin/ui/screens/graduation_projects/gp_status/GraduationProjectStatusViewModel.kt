package com.example.readx.ui.screens.graduation_projects.gp_status

import com.example.readx.ui.Event
import com.example.readx.ui.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class GraduationProjectStatusViewModel @Inject constructor(
) : BaseViewModel<GraduationProjectStatusUIState, GraduationProjectStatusNavigationEvent>(
    GraduationProjectStatusUIState(),
    Event()
) {


}

