package com.example.booksaplicationkotlin.model


import com.google.gson.annotations.SerializedName

data class PaginationLinks(
    @SerializedName("current page")
    var currentPage: Int?,
    @SerializedName("links")
    var links: Links?,
    @SerializedName("per page")
    var perPage: Int?,
    @SerializedName("total")
    var total: Int?
)