package com.example.readx.ui.screens.graduation_projects.projects_viewall

sealed class GraduationProjectsViewallNavigationEvent {
    object NavigateBack: GraduationProjectsViewallNavigationEvent()
    data class NavigateToHome(val userId: Int) : GraduationProjectsViewallNavigationEvent()

}