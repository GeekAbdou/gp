package com.example.readx.ui.screens.graduation_projects.gp_status

data class GraduationProjectStatusUIState(
    val graduationProjectName: String = "",    val errorMessage: String = "",
    var email: String = "",
    )
