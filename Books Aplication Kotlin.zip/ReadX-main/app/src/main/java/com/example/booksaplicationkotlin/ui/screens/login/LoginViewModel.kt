package com.example.readx.ui.screens.login

import android.util.Log
import androidx.lifecycle.viewModelScope
import com.example.booksaplicationkotlin.ReadxSharedPreferences
import com.example.booksaplicationkotlin.model.BaseResponse
import com.example.booksaplicationkotlin.network.IReadxService
import com.example.readx.models.LoginDTO
import com.example.readx.ui.Event
import com.example.readx.ui.base.BaseViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import retrofit2.Response
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val iReadxService: IReadxService,
    private var readxSharedPreferences: ReadxSharedPreferences
) : BaseViewModel<LoginUiState, LoginNavigationEvent>(LoginUiState(), Event()) {

    fun login() {
        val email = state.value.email
        val password = state.value.password


        viewModelScope.launch {
            try {
                val response = iReadxService.loginUser(email, password)
                if (response.isSuccessful) {
                    val loginDTO = response.body()?.data
                    // Print or handle the loginDTO here
                    readxSharedPreferences.saveToken(loginDTO?.token ?: "")
                    Log.d("LOGIN_RESPONSE", "Login successful: $response")
                    navToHome(loginDTO?.ID ?: 0)
                } else {
                    // Handle unsuccessful response here
                    Log.e("LOGIN_ERROR", "Login failed: ${response.errorBody()?.string()}")
                }
            } catch (e: Exception) {
                // Handle exceptions, e.g., show an error message
                Log.e("LOGIN_ERROR", "Login failed: ${e.message}", e)
            }
        }

        Log.d(
            "NONI", "login fun is here email $email, password $password "

        )
    }


    private fun onSuccess(result: Response<BaseResponse<LoginDTO>>) {
        result.let { response ->
            if (response.isSuccessful) {
                val loginDTO = response.body()?.data!!
                saveToken(loginDTO.token)
                navToHome(loginDTO.ID)
                Log.d("LOGIN_RESPONSE", "Login successful: $response")

            } else {
                // Handle unsuccessful response here
                Log.e("LOGIN_ERROR", "Login failed: ${response.errorBody()?.string()}")
            }


        }
    }

    private fun navToHome(id: Int) {
        _event.update { Event(LoginNavigationEvent.NavigateToHome(id)) }
    }

    private fun saveToken(token: String) {
        viewModelScope.launch {
            readxSharedPreferences.saveToken(token)
        }
    }

    private fun onError(e: Throwable) {
//        _state.update {
//            it.copy(isError = e.message.toString())
//        }
    }

    fun onRegisterNowClicked() {
        _event.update { Event(LoginNavigationEvent.NavigateToRegistration) }
    }

}
