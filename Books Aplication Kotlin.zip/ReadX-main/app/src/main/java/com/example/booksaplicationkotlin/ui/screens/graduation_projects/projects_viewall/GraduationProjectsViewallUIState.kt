package com.example.readx.ui.screens.graduation_projects.projects_viewall

data class GraduationProjectsViewallUIState(
    val graduationProjects: List<GraduationProjectsViewallUIState> = emptyList(),
    val graduationProjectName: String = "",
    val graduationProjectDescription: String = "",
    val year: String = "",
    val onBackClick: () -> Unit = {},
    val errorMessage: String = "error",
    val isLoading: Boolean = true,


    )
