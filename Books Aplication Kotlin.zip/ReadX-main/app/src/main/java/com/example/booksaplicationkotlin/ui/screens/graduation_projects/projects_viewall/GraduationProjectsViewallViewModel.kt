package com.example.readx.ui.screens.graduation_projects.projects_viewall

import android.util.Log
import androidx.lifecycle.viewModelScope
import com.example.booksaplicationkotlin.ReadxSharedPreferences
import com.example.booksaplicationkotlin.network.IReadxService
import com.example.readx.ui.Event
import com.example.readx.ui.base.BaseViewModel
import com.example.readx.ui.screens.graduation_projects.GraduationProjectsNavigationEvent
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GraduationProjectsViewallViewModel @Inject constructor(
    private val iReadxService: IReadxService,
    private var readxSharedPreferences: ReadxSharedPreferences
) : BaseViewModel<GraduationProjectsViewallUIState, GraduationProjectsNavigationEvent>(
    GraduationProjectsViewallUIState(),
    Event()
) {
    init {
        getAllGradProjects()
    }

   private fun getAllGradProjects(){
       Log.d("TAG", "getAllGradProjects: ")
        viewModelScope.launch {
            try {
                val token = readxSharedPreferences.getToken() ?: ""
                val response =    state.value.let {
                    iReadxService.getGradProjects(token = token)

                }

                if (response != null) {
                    if (response.isSuccessful) {
                        val responseBody = response.body()
                        if (responseBody != null) {
                            val message = responseBody.msg
                            val data = responseBody.data
                            // Handle successful response with message and data
                            Log.d("API_CALL", "Message: $message, Data: $data")
                        } else {
                            // Handle empty response body
                            Log.d("API_CALL", "Response body is null")
                        }
                    } else {
                        // Handle API error
                        Log.e("API_CALL", "API Error: ${response.code()} - ${response.message()}")
                    }
                }
            } catch (e: Exception) {
                // Handle network or other errors
                Log.e("API_CALL", "Request failed", e)
            }

        }
    }

}

