package com.example.booksaplicationkotlin.ui.screens.allbooks.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import com.example.booksaplicationkotlin.R
import com.example.booksaplicationkotlin.databinding.FragmentBookDetailsBinding


class BookDetailsFragment : Fragment() {

    lateinit var binding: FragmentBookDetailsBinding
    private lateinit var args: BookDetailsFragmentArgs

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_book_details, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        args = navArgs<BookDetailsFragmentArgs>().value
        binding.book = args.book

        binding.showMoreTxt.setOnClickListener {
            if (binding.showMoreTxt.text == "Show more") {
                binding.showMoreTxt.text = "Show Less"
                binding.showArrow.setImageResource(R.drawable.show_less_arrow)
                binding.bookDetailsDescription.apply {
                    this.text = args.book.description
                    this.maxLines = 100
                }


            } else {
                binding.showMoreTxt.text = "Show more"
                binding.showArrow.setImageResource(R.drawable.show_more_arrow)
                binding.bookDetailsDescription.apply {
                    this.text = args.book.description + "..."
                    this.maxLines = 2
                }
            }
        }
    }


}