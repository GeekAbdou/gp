package com.example.booksaplicationkotlin.network

import com.example.booksaplicationkotlin.model.BookResponse
import retrofit2.Response

interface RemoteSource {
    suspend fun  getBooks(token:String):Response<BookResponse>?
    suspend fun getSpecificBook(query:String,filter:String):Response<BookResponse>?
}