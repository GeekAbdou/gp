package com.example.booksaplicationkotlin.ui.screens.allbooks.view

import android.graphics.drawable.Drawable
import android.widget.ImageView
import android.widget.RatingBar
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.example.booksaplicationkotlin.R
import java.net.URL

object BindingUtil {}

