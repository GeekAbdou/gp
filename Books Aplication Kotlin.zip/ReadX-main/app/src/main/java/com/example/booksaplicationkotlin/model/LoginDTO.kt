package com.example.readx.models

data class LoginDTO(
    val ID: Int,
    val name: String,
    val token: String
)