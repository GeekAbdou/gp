package com.example.readx.ui.screens.graduation_projects

data class GraduationProjectsUIState(
    val graduationProjectName: String = "",
    )
