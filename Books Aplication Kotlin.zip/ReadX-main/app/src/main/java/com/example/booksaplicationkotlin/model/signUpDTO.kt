package com.example.readx.models

data class signUpDTO(
    val Id: Int,
    val name: String,
    val token: String
)