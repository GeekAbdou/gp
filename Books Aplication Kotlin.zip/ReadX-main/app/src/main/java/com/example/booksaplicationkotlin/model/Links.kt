package com.example.booksaplicationkotlin.model


import com.google.gson.annotations.SerializedName
data class Links(
    @SerializedName("first")
    var first: String?,
    @SerializedName("last")
    var last: String?,
    @SerializedName("next")
    var next: String?,
    @SerializedName("previous")
    var previous: Any?
)