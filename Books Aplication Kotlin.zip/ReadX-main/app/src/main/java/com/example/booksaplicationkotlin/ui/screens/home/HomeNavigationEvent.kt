package com.example.readx.ui.screens.home

sealed class HomeNavigationEvent {
    object NavigateToLogin: HomeNavigationEvent()

}