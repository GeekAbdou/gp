package com.example.readx.ui.screens.registration

data class RegistrationUIState(
    var firstName: String = "",
    var lastName: String = "",
    var email: String = "",
    var password: String = "",
    var passwordConfirmation: String = "",
    var studentId: String="" ,
)

