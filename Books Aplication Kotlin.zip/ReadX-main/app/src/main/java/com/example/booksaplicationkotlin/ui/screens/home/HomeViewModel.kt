package com.example.readx.ui.screens.home

import android.util.Log
import androidx.lifecycle.viewModelScope
import com.example.booksaplicationkotlin.ReadxSharedPreferences
import com.example.booksaplicationkotlin.network.IReadxService
import com.example.readx.ui.Event
import com.example.readx.ui.base.BaseViewModel
import com.example.readx.ui.screens.login.LoginUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private var readxSharedPreferences: ReadxSharedPreferences,
    private val readXService: IReadxService,

    ) : BaseViewModel<LoginUiState, HomeNavigationEvent>(LoginUiState(), Event()) {

    init {
        val token = readxSharedPreferences.getToken()
        navToLoginIfTokenIsExist(token)
       /* if (token != null || token == "") {
            getExams(token)
            getGradProjects(token)
            getBooks(token)
        }*/
    }


    private fun getExams(token: String) {
        viewModelScope.launch {
            readXService.getExams(token)
            try {
                val response = readXService.getExams(token = token)

                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        val message = responseBody.msg
                        val data = responseBody.data
                        // Handle successful response with message and data
                        Log.d("API_CALL", "Message: $message, Data: $data")
                    } else {
                        // Handle empty response body
                        Log.d("API_CALL", "Response body is null")
                    }
                } else {
                    // Handle API error
                    Log.e("API_CALL", "API Error: ${response.code()} - ${response.message()}")
                }
            } catch (e: Exception) {
                // Handle network or other errors
                Log.e("API_CALL", "Request failed", e)
            }

        }
    }

    private fun getGradProjects(token: String) {
        viewModelScope.launch {
            readXService.getExams(token)
            try {
                val response = readXService.getGradProjects(token = token)

                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        val message = responseBody.msg
                        val data = responseBody.data
                        // Handle successful response with message and data
                        Log.d("API_CALL", "Message: $message, Data: $data")
                    } else {
                        // Handle empty response body
                        Log.d("API_CALL", "Response body is null")
                    }
                } else {
                    // Handle API error
                    Log.e("API_CALL", "API Error: ${response.code()} - ${response.message()}")
                }
            } catch (e: Exception) {
                // Handle network or other errors
                Log.e("API_CALL", "Request failed", e)
            }

        }

    }

    private fun getBooks(token: String) {
        viewModelScope.launch {
            readXService.getExams(token)
            try {
                val response = readXService.getBooks(token = token)

                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        val message = responseBody.msg
                        val data = responseBody.data
                        // Handle successful response with message and data
                        Log.d("API_CALL", "Message: $message, Data: $data")
                    } else {
                        // Handle empty response body
                        Log.d("API_CALL", "Response body is null")
                    }
                } else {
                    // Handle API error
                    Log.e("API_CALL", "API Error: ${response.code()} - ${response.message()}")
                }
            } catch (e: Exception) {
                // Handle network or other errors
                Log.e("API_CALL", "Request failed", e)
            }

        }

    }


    private fun navToLoginIfTokenIsExist(token: String?) {
        viewModelScope.launch {
            Log.d("TAG", "token:$token ")
            if (token?.isEmpty() == true) {
                _event.update { Event(HomeNavigationEvent.NavigateToLogin) }
            }

        }
    }
}